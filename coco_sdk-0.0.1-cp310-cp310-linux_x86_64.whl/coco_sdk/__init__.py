from .camera_driver_ext import (
    PixelFormat,
    CameraDriverOptions,
    CameraDriver as _ExtCameraDriver,
)


class CameraDriver:
    """
    CameraDriver wrapper to allow specifying either a custom GStreamer pipeline string
    or parameters for a UDP H264 pipeline. Exactly one of 'pipeline' or the group
    ('interface', 'port', 'decoder') must be provided.

    Args:
        pipeline (str): GStreamer pipeline string without the final appsink element.
        options (CameraDriverOptions): Camera driver options.
        interface (str): Multicast interface name (e.g., 'eth0').
        port (int): UDP port number.
    """

    def __init__(
        self,
        pipeline: str = None,
        options: CameraDriverOptions = None,
        *,
        interface: str = None,
        port: int = None,
    ):
        if pipeline is not None and (interface or port):
            raise ValueError("Specify either 'pipeline' or 'interface/port', not both")
        if pipeline is None:
            if not (interface and port):
                raise ValueError("If 'pipeline' is omitted, 'interface' and 'port' must be provided")
            caps = (
                "application/x-rtp, media=video, encoding-name=(string)H264, " "payload=(int)96, clock-rate=(int)90000"
            )
            pipeline = (
                f"udpsrc multicast-iface={interface} address=224.0.0.210 port={port} "
                f'caps="{caps}" ! rtph264depay ! '
                "video/x-h264,stream-format=byte-stream,alignment=au ! "
                "h264parse ! "
                "video/x-h264,stream-format=byte-stream,alignment=au ! "
                f"avdec_h264 ! "
                "videoconvert"
            )
        self._driver = _ExtCameraDriver(pipeline, options or CameraDriverOptions())

    def pop_frame(self, timeout_ms: int = -1):
        """Blocking pop of a single frame with the given timeout in milliseconds."""
        return self._driver.pop_frame(timeout_ms=timeout_ms)

    def __getattr__(self, name):
        # Delegate other attributes to the underlying extension driver
        return getattr(self._driver, name)
